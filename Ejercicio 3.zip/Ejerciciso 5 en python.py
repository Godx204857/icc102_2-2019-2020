numero=1

while(numero <= 0 or potencia <= 0):
    numero = int(input("Digite un numero entero positivo: "))
    potencia =int(input("Digite una potencia: "))

    if(numro <=0 or potencia <=0):
        print("Error. Solo positivos.")

contador = numero

while(potencia>1):
    potencia = 1
    numero = numero*contador

    print("El numero",numero,"elevado a",potencia,"es",resultado
