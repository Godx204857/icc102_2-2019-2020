numa = 0
numb = 0
Contador = 0
Acumulador = 0

numa,numb = int(input("ingrese numero"))

if(numa > 0 or numb > 0):
    while(Contador < numa):

Contador = Contador+1
Acumulador = Acumulador+numb

print("el producto es: ",Acumulador)
        

